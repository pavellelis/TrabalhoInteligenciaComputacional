# experiment_manager.py
import numpy as np
import matplotlib.pyplot as plt
import os
from main_runner import run_single_asPSO_run

# ... (OPTIMIZER_PARAMS_BASE e EXPERIMENT_CONFIGS como antes) ...
OPTIMIZER_PARAMS_BASE = {
    'SwarmMember': 5,
    'InitialPopulationSize': 50,
    'NewlyAddedPopulationSize': 5,
    'PSO_Inertia': 0.729843788,
    'PSO_c1': 2.05,
    'PSO_c2': 2.05,
    'Nmax': 30,
    'RhoDeactivation': 0.7,
    'MuDeactivation': 0.2,
    'GammaDeactivation': 0.1
}
EXPERIMENT_CONFIGS = {
    "1": {"name": "Fig1a_D5_m10_F5000_S1_Tplot20", "PeakNumber": 10, "ChangeFrequency": 5000, "Dimension": 5,
          "ShiftSeverity": 1.0, "EnvironmentNumber": 100, "T_plot": 20, "RunNumber": 31},
    # Reduzido RunNumber para teste rápido
    "2": {"name": "Fig1b_D5_m100_F5000_S1_Tplot20", "PeakNumber": 100, "ChangeFrequency": 5000, "Dimension": 5,
          "ShiftSeverity": 1.0, "EnvironmentNumber": 100, "T_plot": 20, "RunNumber": 31},
    "3": {"name": "Fig1c_D10_m10_F500_S1_Tplot20", "PeakNumber": 10, "ChangeFrequency": 500, "Dimension": 10,
          "ShiftSeverity": 1.0, "EnvironmentNumber": 100, "T_plot": 20, "RunNumber": 31},
    "4": {"name": "Fig1d_D10_m10_F2500_S1_Tplot20", "PeakNumber": 10, "ChangeFrequency": 2500, "Dimension": 10,
          "ShiftSeverity": 1.0, "EnvironmentNumber": 100, "T_plot": 20, "RunNumber": 31},
    "5": {"name": "Table4_D5_m25_F5000_S1_T100", "PeakNumber": 25, "ChangeFrequency": 5000, "Dimension": 5,
          "ShiftSeverity": 1.0, "EnvironmentNumber": 100, "T_plot": 100, "RunNumber": 31}
}


def aggregate_history_data_by_environment(history_list, env_markers_list, total_environments):
    # ... (código existente) ...
    data_per_env = [[] for _ in range(total_environments)]
    if not history_list or not env_markers_list: return np.array([np.nan] * total_environments)

    min_len = min(len(h) for h in history_list if
                  h is not None)  # Garante que todos tenham o mesmo comprimento para agregação por iteração

    # Se env_markers_list for uma lista de listas (uma por run)
    # e history_list também, precisamos alinhar.
    # Esta função é mais para métricas por *ambiente*.
    # Para métricas por *iteração* que serão plotadas contra FEs, a abordagem é diferente.

    for i in range(len(history_list)):
        run_data = history_list[i]
        run_envs = env_markers_list[i]
        if run_data is None or run_envs is None: continue

        for k in range(len(run_data)):  # Itera sobre os registros da run
            if k < len(run_envs):  # Verifica se temos um marcador de ambiente para este dado
                env_idx = run_envs[k]
                if 0 <= env_idx < total_environments:
                    data_per_env[env_idx].append(run_data[k])

    mean_per_env = np.array([np.nanmean(vals) if vals else np.nan for vals in data_per_env])
    return mean_per_env


def align_and_average_history_vs_fe(history_data_all_runs, fe_markers_all_runs, max_fes_to_plot):
    """Alinha dados históricos com um eixo de FEs e calcula média e desvio padrão."""
    aligned_data_for_runs = []

    # Define um eixo comum de FEs para interpolação/mapeamento
    common_fe_axis = np.arange(1, max_fes_to_plot + 1)

    for i in range(len(history_data_all_runs)):  # Para cada run
        run_metric_history = history_data_all_runs[i]
        run_fe_history = fe_markers_all_runs[i]

        if run_metric_history is None or run_fe_history is None or len(run_metric_history) == 0 or len(
                run_fe_history) == 0:
            aligned_data_for_runs.append(np.full(max_fes_to_plot, np.nan))
            continue

        # Interpola os dados da run para o eixo comum de FEs
        # Remove duplicados de FEs mantendo o último valor da métrica para aquele FE
        unique_fes, unique_indices = np.unique(run_fe_history, return_index=True)
        unique_metrics = run_metric_history[unique_indices]

        # Garante que os FEs estejam dentro do limite de plotagem e remove NaNs se houver
        valid_mask = (unique_fes <= max_fes_to_plot) & (~np.isnan(unique_metrics)) & (~np.isnan(unique_fes))
        unique_fes = unique_fes[valid_mask]
        unique_metrics = unique_metrics[valid_mask]

        if len(unique_fes) > 1:  # np.interp precisa de pelo menos 2 pontos
            # Adiciona o valor do primeiro FE válido ao início do common_fe_axis se não estiver lá
            interp_fes = common_fe_axis
            interp_metrics = np.interp(interp_fes, unique_fes, unique_metrics, left=unique_metrics[0],
                                       right=unique_metrics[-1])
        elif len(unique_fes) == 1:  # Apenas um ponto, preenche com ele
            interp_metrics = np.full(max_fes_to_plot, unique_metrics[0])
        else:  # Nenhum dado válido
            interp_metrics = np.full(max_fes_to_plot, np.nan)

        aligned_data_for_runs.append(interp_metrics)

    if not aligned_data_for_runs:
        return np.full(max_fes_to_plot, np.nan), np.full(max_fes_to_plot, np.nan)

    mean_over_runs = np.nanmean(np.array(aligned_data_for_runs), axis=0)
    std_over_runs = np.nanstd(np.array(aligned_data_for_runs), axis=0)

    return mean_over_runs, std_over_runs


def run_experiments_for_config(config_choice):
    # ... (início como antes) ...
    if str(config_choice) not in EXPERIMENT_CONFIGS:
        print("Escolha de configuração inválida.")
        return

    config = EXPERIMENT_CONFIGS[str(config_choice)]
    problem_params = {k: v for k, v in config.items() if k not in ["name", "T_plot", "RunNumber"]}
    num_runs = config["RunNumber"]
    max_evals_total_per_run = problem_params['ChangeFrequency'] * problem_params['EnvironmentNumber']
    total_environments = problem_params['EnvironmentNumber']

    all_runs_current_errors = np.full((num_runs, max_evals_total_per_run), np.nan)
    all_runs_offline_errors = np.full(num_runs, np.nan)

    # Listas para armazenar os históricos de todas as runs
    all_runs_history_num_species_ac = [None] * num_runs
    all_runs_history_num_valid_species_bp = [None] * num_runs
    all_runs_history_deactivation_radius = [None] * num_runs
    all_runs_history_shift_severity = [None] * num_runs
    all_runs_history_env_for_shift = [None] * num_runs
    all_runs_history_env_for_species_radius = [None] * num_runs
    # Novos
    all_runs_history_total_particles = [None] * num_runs
    all_runs_history_total_valid_species_iter = [None] * num_runs
    all_runs_history_active_species_iter = [None] * num_runs
    all_runs_history_fe_at_iteration_end = [None] * num_runs

    print(f"\n--- Executando Configuração: {config['name']} ---")
    print(f"Parâmetros do Problema: {problem_params}")
    print(f"Parâmetros Base do Otimizador: {OPTIMIZER_PARAMS_BASE}")  # Adicionado para clareza
    print(f"Número de Execuções (Runs): {num_runs}\n")

    for r in range(num_runs):
        current_error_this_run, offline_error_this_run, run_history_data = run_single_asPSO_run(
            problem_params, OPTIMIZER_PARAMS_BASE, run_seed=r
        )
        # ... (armazenamento de current_error e offline_error como antes) ...
        len_run_error = len(current_error_this_run)
        if len_run_error <= max_evals_total_per_run:
            all_runs_current_errors[r, :len_run_error] = current_error_this_run
        else:
            all_runs_current_errors[r, :] = current_error_this_run[:max_evals_total_per_run]
        all_runs_offline_errors[r] = offline_error_this_run

        all_runs_history_num_species_ac[r] = run_history_data["num_species_after_creation"]
        all_runs_history_num_valid_species_bp[r] = run_history_data["num_valid_species_before_pso"]
        all_runs_history_deactivation_radius[r] = run_history_data["current_deactivation_radius"]
        all_runs_history_shift_severity[r] = run_history_data["estimated_shift_severity"]
        all_runs_history_env_for_shift[r] = run_history_data["env_for_shift"]
        all_runs_history_env_for_species_radius[r] = run_history_data["env_for_species_radius"]
        # Novos
        all_runs_history_total_particles[r] = run_history_data["total_particles"]
        all_runs_history_total_valid_species_iter[r] = run_history_data["total_valid_species_iter"]
        all_runs_history_active_species_iter[r] = run_history_data["active_species_iter"]
        all_runs_history_fe_at_iteration_end[r] = run_history_data["fe_at_iteration_end"]

        print(f"Run {r + 1}/{num_runs} - Erro Offline Calculado: {offline_error_this_run:.4f}")

    # ... (cálculo de estatísticas de erro offline como antes) ...
    mean_offline_error = np.nanmean(all_runs_offline_errors)
    std_offline_error = np.nanstd(all_runs_offline_errors)
    sem_offline_error = std_offline_error / np.sqrt(num_runs) if num_runs > 0 and not np.isnan(
        std_offline_error) else np.nan

    output_dir_config = f"experiment_outputs_ASPSO_Python_{config['name']}"  # Diretório específico da config
    os.makedirs(output_dir_config, exist_ok=True)

    print_and_save_offline_error_stats(config, problem_params, num_runs, mean_offline_error, std_offline_error,
                                       sem_offline_error, all_runs_offline_errors, output_dir_config)
    plot_mean_current_error(all_runs_current_errors, config, problem_params, max_evals_total_per_run, output_dir_config)

    # --- PLOTAGEM DOS NOVOS GRÁFICOS ---
    evals_to_plot_on_graph = min(config['T_plot'] * problem_params['ChangeFrequency'], max_evals_total_per_run)
    common_fe_axis_for_plot = np.arange(1, evals_to_plot_on_graph + 1)

    # Gráfico: Tamanho Médio da População (Número de Partículas)
    mean_particles, std_particles = align_and_average_history_vs_fe(
        all_runs_history_total_particles,
        all_runs_history_fe_at_iteration_end,
        evals_to_plot_on_graph
    )
    plt.figure(figsize=(12, 6))  # Ajustado para um subplot
    plt.plot(common_fe_axis_for_plot, mean_particles, label="Tamanho Médio da População", color="green")
    plt.fill_between(common_fe_axis_for_plot, mean_particles - std_particles, mean_particles + std_particles,
                     color="lightgreen", alpha=0.5)
    plt.xlabel("Avaliações de Fitness (FEs)")
    plt.ylabel("Número de Partículas")
    plt.title(f"Dinâmica Populacional Média - {config['name']}")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir_config, f"plot_avg_population_size_{config['name']}.png"))
    plt.close()
    print(
        f"Gráfico de Tamanho Médio da População salvo em: {os.path.join(output_dir_config, f'plot_avg_population_size_{config['name']}.png')}")

    # Gráfico: Número de Espécies (Total Válida e Ativas)
    mean_total_species, std_total_species = align_and_average_history_vs_fe(
        all_runs_history_total_valid_species_iter,
        all_runs_history_fe_at_iteration_end,
        evals_to_plot_on_graph
    )
    mean_active_species, std_active_species = align_and_average_history_vs_fe(
        all_runs_history_active_species_iter,
        all_runs_history_fe_at_iteration_end,
        evals_to_plot_on_graph
    )
    plt.figure(figsize=(12, 6))  # Ajustado para um subplot
    plt.plot(common_fe_axis_for_plot, mean_total_species, label="Espécies (Total Válida)", color="orangered")
    plt.fill_between(common_fe_axis_for_plot, mean_total_species - std_total_species,
                     mean_total_species + std_total_species, color="lightsalmon", alpha=0.5)
    plt.plot(common_fe_axis_for_plot, mean_active_species, label="Espécies (Ativas)", color="firebrick", linestyle="--")
    plt.fill_between(common_fe_axis_for_plot, mean_active_species - std_active_species,
                     mean_active_species + std_active_species, color="lightcoral", alpha=0.4)
    plt.xlabel("Avaliações de Fitness (FEs)")
    plt.ylabel("Número de Espécies")
    plt.title(f"Dinâmica de Espécies Média - {config['name']}")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir_config, f"plot_avg_species_counts_{config['name']}.png"))
    plt.close()
    print(
        f"Gráfico de Contagem Média de Espécies salvo em: {os.path.join(output_dir_config, f'plot_avg_species_counts_{config['name']}.png')}")

    # Gráficos por ambiente (como antes, se desejar)
    # mean_num_valid_species_per_env = aggregate_history_data_by_environment(...)
    # plot_history_metric_per_environment(...)
    # mean_deactivation_radius_per_env = aggregate_history_data_by_environment(...)
    # plot_history_metric_per_environment(...)
    # mean_shift_severity_per_env = aggregate_history_data_by_environment(...)
    # plot_history_metric_per_environment(...)

    plot_offline_error_distribution(all_runs_offline_errors, config['name'], output_dir_config)


def print_and_save_offline_error_stats(config, problem_params, num_runs, mean_offline_error, std_offline_error,
                                       sem_offline_error, all_runs_offline_errors, output_dir):
    # ... (código existente, mas usa o output_dir passado) ...
    results_summary_filename = os.path.join(output_dir, f"results_summary_{config['name']}.txt")
    # ... (resto da função como antes) ...
    header = f"Resultados para Configuração: {config['name']}"
    stats_output = (
        f"{header}\n"
        f"{'=' * len(header)}\n"
        f"Parâmetros do Problema:\n{problem_params}\n\n"
        f"Parâmetros Base do Otimizador:\n{OPTIMIZER_PARAMS_BASE}\n\n"
        f"Número de Execuções (Runs): {num_runs}\n\n"
        f"Estatísticas do Erro Offline (E_o):\n"
        f"  Média (Mean): {mean_offline_error:.6f}\n"
        f"  Desvio Padrão (Std Dev): {std_offline_error:.6f}\n"
        f"  Erro Padrão da Média (SEM): {sem_offline_error:.6f}\n\n"
        "Erro Offline por Run:\n"
    )
    for r_idx, off_err in enumerate(all_runs_offline_errors):
        stats_output += f"  Run {r_idx + 1}: {off_err:.6f}\n"

    print(stats_output)
    with open(results_summary_filename, "w", encoding='utf-8') as f:  # Adicionado encoding
        f.write(stats_output)
    print(f"Resultados numéricos resumidos salvos em: {results_summary_filename}")


def plot_mean_current_error(all_runs_current_errors, config, problem_params, max_evals_total_per_run, output_dir):
    # ... (código existente, mas usa o output_dir passado) ...
    evals_to_plot_on_graph = min(config['T_plot'] * problem_params['ChangeFrequency'], max_evals_total_per_run)
    mean_current_error_for_plot = np.nanmean(all_runs_current_errors[:, :evals_to_plot_on_graph], axis=0)
    evaluations_axis_for_plot = np.arange(1, evals_to_plot_on_graph + 1)

    plt.figure(figsize=(12, 7))
    plt.plot(evaluations_axis_for_plot, mean_current_error_for_plot)
    plt.xlabel("Avaliações de Fitness")
    plt.ylabel("Erro Corrente Médio")
    plt.title(f"Erro Corrente Médio vs Avaliações\nConfig: {config['name']}")
    plt.grid(True)
    plt.tight_layout()
    plot_filename = os.path.join(output_dir, f"plot_current_error_{config['name']}.png")
    plt.savefig(plot_filename)
    plt.close()
    print(f"Gráfico de Erro Corrente Médio salvo em: {plot_filename}")


def plot_history_metric_per_environment(data_per_env, env_axis, metric_name, config_name, output_dir, filename_suffix,
                                        xlabel="Número do Ambiente"):
    # ... (código existente, mas usa o output_dir passado) ...
    plt.figure(figsize=(10, 6))
    plt.plot(env_axis, data_per_env, marker='o', linestyle='-')  # Adicionado marker para clareza
    plt.xlabel(xlabel)
    plt.ylabel(metric_name)
    plt.title(f"{metric_name} por Ambiente\nConfig: {config_name}")
    plt.grid(True)
    plt.tight_layout()
    plot_filename = os.path.join(output_dir, f"plot_{filename_suffix}_{config_name}.png")
    plt.savefig(plot_filename)
    plt.close()
    print(f"Gráfico de {metric_name} salvo em: {plot_filename}")


def plot_offline_error_distribution(all_runs_offline_errors, config_name, output_dir):
    # ... (código existente, mas usa o output_dir passado) ...
    plt.figure(figsize=(8, 6))
    # Remove NaNs antes de plotar, pois boxplot não lida bem com eles
    valid_offline_errors = all_runs_offline_errors[~np.isnan(all_runs_offline_errors)]
    if len(valid_offline_errors) > 0:
        plt.boxplot(valid_offline_errors)
    else:
        plt.text(0.5, 0.5, "Sem dados de erro offline para plotar", ha='center', va='center')

    plt.ylabel("Erro Offline Final")
    plt.title(f"Distribuição do Erro Offline Final\nConfig: {config_name}")
    # Tenta simplificar o label do eixo x, pegando a primeira parte do nome da config se houver '_'
    xtick_label = config_name.split('_')[0] if '_' in config_name else config_name
    if len(valid_offline_errors) > 0:
        plt.xticks([1], [xtick_label])
    else:
        plt.xticks([])
    plt.grid(True, axis='y')
    plt.tight_layout()
    plot_filename = os.path.join(output_dir, f"plot_boxplot_offline_error_{config_name}.png")
    plt.savefig(plot_filename)
    plt.close()
    print(f"Gráfico Boxplot do Erro Offline salvo em: {plot_filename}")


if __name__ == "__main__":
    # ... (menu como antes) ...
    while True:
        print("\n--- ASPSO (SPSO+AP+AD) Python Implementation ---")
        print("Escolha a configuração do experimento para rodar (Cenário 1 do paper):")
        for key, cfg_item in EXPERIMENT_CONFIGS.items():
            dim_cfg = cfg_item['Dimension']
            m_cfg = cfg_item['PeakNumber']
            freq_cfg = cfg_item['ChangeFrequency']
            shift_cfg = cfg_item['ShiftSeverity']
            t_plot_cfg = cfg_item.get('T_plot', cfg_item['EnvironmentNumber'])
            desc = ""
            if cfg_item['name'].startswith("Fig1a"):
                desc = f"Fig 1a (D={dim_cfg}, m={m_cfg}, Freq={freq_cfg}, Shift={shift_cfg}, T_plot={t_plot_cfg})"
            elif cfg_item['name'].startswith("Fig1b"):
                desc = f"Fig 1b (D={dim_cfg}, m={m_cfg}, Freq={freq_cfg}, Shift={shift_cfg}, T_plot={t_plot_cfg})"
            elif cfg_item['name'].startswith("Fig1c"):
                desc = f"Fig 1c (D={dim_cfg}, m={m_cfg}, Freq={freq_cfg}, Shift={shift_cfg}, T_plot={t_plot_cfg})"
            elif cfg_item['name'].startswith("Fig1d"):
                desc = f"Fig 1d (D={dim_cfg}, m={m_cfg}, Freq={freq_cfg}, Shift={shift_cfg}, T_plot={t_plot_cfg})"
            elif cfg_item['name'].startswith("Table4"):
                desc = f"Tabela 4 (D={dim_cfg}, m={m_cfg}, Freq={freq_cfg}, Shift={shift_cfg}, T_total={cfg_item['EnvironmentNumber']})"
            else:
                desc = cfg_item['name']
            print(f"{key}: {desc}")
        print("0: Sair")
        user_choice = input("Digite sua escolha: ")
        if user_choice == '0':
            print("Encerrando.")
            break
        if user_choice in EXPERIMENT_CONFIGS:
            run_experiments_for_config(user_choice)
        else:
            print("Escolha inválida. Por favor, tente novamente.")