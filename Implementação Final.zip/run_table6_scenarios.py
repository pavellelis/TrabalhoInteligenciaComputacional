# run_table6_scenarios.py
import numpy as np
import matplotlib.pyplot as plt
import os
from main_runner import run_single_asPSO_run

# --- Parâmetros Base do Otimizador (idênticos ao script anterior) ---
OPTIMIZER_PARAMS_BASE = {
    'SwarmMember': 5,
    'InitialPopulationSize': 50,
    'NewlyAddedPopulationSize': 5,
    'PSO_Inertia': 0.729843788,
    'PSO_c1': 2.05,
    'PSO_c2': 2.05,
    'Nmax': 30,
    'RhoDeactivation': 0.7,
    'MuDeactivation': 0.2,
    'GammaDeactivation': 0.1
}

# --- Configurações de Problemas para os Cenários da Tabela 6 ---
# Parâmetros fixos para esta tabela: m=10, ϑ=5000
# A variável é a Severidade da Mudança (s̃)
TABLE6_EXPERIMENT_CONFIGS = {
    "1": {
        "name": "Table6_s1_D5_m10_F5000",
        "PeakNumber": 10, "ChangeFrequency": 5000, "Dimension": 5,
        "ShiftSeverity": 1.0, "EnvironmentNumber": 100, "T_plot": 20, "RunNumber": 31
    },
    "2": {
        "name": "Table6_s2_D5_m10_F5000",
        "PeakNumber": 10, "ChangeFrequency": 5000, "Dimension": 5,
        "ShiftSeverity": 2.0, "EnvironmentNumber": 100, "T_plot": 20, "RunNumber": 31
    },
    "3": {
        "name": "Table6_s5_D5_m10_F5000",
        "PeakNumber": 10, "ChangeFrequency": 5000, "Dimension": 5,
        "ShiftSeverity": 5.0, "EnvironmentNumber": 100, "T_plot": 20, "RunNumber": 31
    }
}


# As funções de execução, agregação e plotagem são reutilizadas do script anterior.
# Por conveniência, elas estão incluídas aqui novamente.

def run_experiments_for_config(config, all_configs):
    """Função principal que executa os experimentos para uma dada configuração."""
    problem_params = {k: v for k, v in config.items() if k not in ["name", "T_plot", "RunNumber"]}
    num_runs = config["RunNumber"]
    max_evals_total_per_run = problem_params['ChangeFrequency'] * problem_params['EnvironmentNumber']

    # Arrays para armazenar resultados
    all_runs_current_errors = np.full((num_runs, max_evals_total_per_run), np.nan)
    all_runs_offline_errors = np.full(num_runs, np.nan)

    print(f"\n--- Executando Configuração: {config['name']} ---")
    print(f"Parâmetros do Problema: {problem_params}")
    print(f"Número de Execuções (Runs): {num_runs}\n")

    for r in range(num_runs):
        current_error_this_run, offline_error_this_run, _ = run_single_asPSO_run(
            problem_params,
            OPTIMIZER_PARAMS_BASE,
            run_seed=r
        )
        # Armazenar resultados (ignora o dicionário de histórico por simplicidade aqui)
        len_run_error = len(current_error_this_run)
        if len_run_error <= max_evals_total_per_run:
            all_runs_current_errors[r, :len_run_error] = current_error_this_run
        else:
            all_runs_current_errors[r, :] = current_error_this_run[:max_evals_total_per_run]
        all_runs_offline_errors[r] = offline_error_this_run
        print(f"Run {r + 1}/{num_runs} - Erro Offline Calculado: {offline_error_this_run:.4f}")

    # Calcular estatísticas finais
    mean_offline_error = np.nanmean(all_runs_offline_errors)
    std_offline_error = np.nanstd(all_runs_offline_errors)
    sem_offline_error = std_offline_error / np.sqrt(num_runs) if num_runs > 0 and not np.isnan(
        std_offline_error) else np.nan

    # Salvar e imprimir resultados
    output_dir = f"experiment_outputs_ASPSO_Python_{config['name']}"
    os.makedirs(output_dir, exist_ok=True)

    # Imprimir e salvar o resumo do erro offline
    print_and_save_offline_error_stats(config, problem_params, num_runs, mean_offline_error, std_offline_error,
                                       sem_offline_error, all_runs_offline_errors, output_dir)

    # Plotar e salvar o gráfico do erro corrente médio
    plot_mean_current_error(all_runs_current_errors, config, problem_params, max_evals_total_per_run, output_dir)


def print_and_save_offline_error_stats(config, problem_params, num_runs, mean_offline_error, std_offline_error,
                                       sem_offline_error, all_runs_offline_errors, output_dir):
    """Imprime e salva estatísticas do erro offline."""
    results_summary_filename = os.path.join(output_dir, f"results_summary_{config['name']}.txt")
    header = f"Resultados para Configuração: {config['name']}"
    stats_output = (
        f"{header}\n"
        f"{'=' * len(header)}\n"
        f"Parâmetros do Problema:\n{problem_params}\n\n"
        f"Parâmetros Base do Otimizador:\n{OPTIMIZER_PARAMS_BASE}\n\n"
        f"Número de Execuções (Runs): {num_runs}\n\n"
        f"Estatísticas do Erro Offline (E_o):\n"
        f"  Média (Mean): {mean_offline_error:.6f}\n"
        f"  Desvio Padrão (Std Dev): {std_offline_error:.6f}\n"
        f"  Erro Padrão da Média (SEM): {sem_offline_error:.6f}\n\n"
        "Erro Offline por Run:\n"
    )
    for r_idx, off_err in enumerate(all_runs_offline_errors):
        stats_output += f"  Run {r_idx + 1}: {off_err:.6f}\n"

    print(stats_output)
    with open(results_summary_filename, "w", encoding='utf-8') as f:
        f.write(stats_output)
    print(f"Resultados numéricos resumidos salvos em: {results_summary_filename}")


def plot_mean_current_error(all_runs_current_errors, config, problem_params, max_evals_total_per_run, output_dir):
    """Plota o erro corrente médio."""
    evals_to_plot_on_graph = min(config['T_plot'] * problem_params['ChangeFrequency'], max_evals_total_per_run)
    mean_current_error_for_plot = np.nanmean(all_runs_current_errors[:, :evals_to_plot_on_graph], axis=0)
    evaluations_axis_for_plot = np.arange(1, evals_to_plot_on_graph + 1)

    plt.figure(figsize=(12, 7))
    plt.plot(evaluations_axis_for_plot, mean_current_error_for_plot)
    plt.xlabel("Avaliações de Fitness")
    plt.ylabel("Erro Corrente Médio")
    plt.title(f"Erro Corrente Médio vs Avaliações\nConfig: {config['name']}")
    plt.grid(True)
    plt.tight_layout()
    plot_filename = os.path.join(output_dir, f"plot_current_error_{config['name']}.png")
    plt.savefig(plot_filename)
    plt.close()
    print(f"Gráfico de Erro Corrente Médio salvo em: {plot_filename}")


if __name__ == "__main__":
    while True:
        print("\n--- Testador de Cenários da Tabela 6 (Shift Severity) ---")
        print("Escolha o cenário para executar:")
        for key, cfg_item in TABLE6_EXPERIMENT_CONFIGS.items():
            print(f"{key}: s̃ = {cfg_item['ShiftSeverity']} (Severidade da Mudança)")

        print("0: Sair")

        user_choice = input("Digite sua escolha: ")
        if user_choice == '0':
            print("Encerrando.")
            break
        if user_choice in TABLE6_EXPERIMENT_CONFIGS:
            run_experiments_for_config(TABLE6_EXPERIMENT_CONFIGS[user_choice], TABLE6_EXPERIMENT_CONFIGS)
        else:
            print("Escolha inválida. Por favor, tente novamente.")