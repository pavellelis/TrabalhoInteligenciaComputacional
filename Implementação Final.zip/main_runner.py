# main_runner.py
import numpy as np
from gmpb_problem import GMPBProblem
from asPSO_optimizer import ASPSOOptimizer # Certifique-se que esta linha está correta
import time

def run_single_asPSO_run(problem_params, optimizer_params_base, run_seed):
    print(f"--- Iniciando Run: {run_seed + 1} ---")
    np.random.seed(run_seed)
    problem = GMPBProblem(
        PeakNumber=problem_params['PeakNumber'],
        ChangeFrequency=problem_params['ChangeFrequency'],
        Dimension=problem_params['Dimension'],
        ShiftSeverity=problem_params['ShiftSeverity'],
        EnvironmentNumber=problem_params['EnvironmentNumber'],
        MinCoordinate=problem_params.get('MinCoordinate', -100),
        MaxCoordinate=problem_params.get('MaxCoordinate', 100)
    )
    np.random.seed(run_seed + 1000) # Seed para o otimizador
    optimizer = ASPSOOptimizer(
        problem_dimension=problem.Dimension,
        min_coord=problem.MinCoordinate,
        max_coord=problem.MaxCoordinate,
        peak_number_initial=problem.PeakNumber,
        # ... (outros parâmetros do otimizador como antes) ...
        swarm_member_size=optimizer_params_base.get('SwarmMember', 5),
        initial_population_size=optimizer_params_base.get('InitialPopulationSize', 50),
        newly_added_population_size=optimizer_params_base.get('NewlyAddedPopulationSize', 5),
        pso_inertia_weight=optimizer_params_base.get('PSO_Inertia', 0.729843788),
        pso_c1=optimizer_params_base.get('PSO_c1', 2.05),
        pso_c2=optimizer_params_base.get('PSO_c2', 2.05),
        n_max_species=optimizer_params_base.get('Nmax', 30),
        rho_deactivation=optimizer_params_base.get('RhoDeactivation', 0.7),
        mu_deactivation=optimizer_params_base.get('MuDeactivation', 0.2),
        gamma_deactivation=optimizer_params_base.get('GammaDeactivation', 0.1)
    )
    optimizer.initialize_population(problem)
    iteration = 0
    max_iterations_safety = problem.MaxEvals * 2 + 100

    while problem.FE < problem.MaxEvals and iteration < max_iterations_safety:
        iteration += 1
        optimizer.optimize_step(problem)
        if problem.RecentChange:
            # print(f"Run {run_seed + 1}, Env {problem.Environmentcounter + 1}/{problem.EnvironmentNumber}, FEs {problem.FE}/{problem.MaxEvals}") # Comentado
            optimizer.reaction_to_change(problem)
            problem.RecentChange = False
        # if iteration % 200 == 0 and not problem.RecentChange: # Comentado para reduzir output
        #     if problem.FE < problem.MaxEvals:
        #         print(f"Run {run_seed + 1}, Iter {iteration}, Env {problem.Environmentcounter +1}, FEs {problem.FE}/{problem.MaxEvals}")


    # ... (lógica de finalização e cálculo de erro offline como antes) ...
    if problem.FE >= problem.MaxEvals:
        print(f"--- Run {run_seed + 1} concluída. Total FEs: {problem.FE} ---")
    elif iteration >= max_iterations_safety:
        print(f"--- Run {run_seed + 1} interrompida por safety break. Iter: {iteration}, FEs: {problem.FE} ---")

    actual_fes_recorded = min(problem.FE, problem.MaxEvals)
    valid_current_errors = problem.CurrentError[:actual_fes_recorded]
    offline_error_run = np.nanmean(valid_current_errors) if len(valid_current_errors) > 0 else np.nan


    # --- ATUALIZADO PARA RETORNAR NOVOS HISTÓRICOS ---
    run_history = {
        "num_species_after_creation": np.array(optimizer.history_num_species_after_creation),
        "num_valid_species_before_pso": np.array(optimizer.history_num_valid_species_before_pso),
        "current_deactivation_radius": np.array(optimizer.history_current_deactivation_radius),
        "estimated_shift_severity": np.array(optimizer.history_estimated_shift_severity),
        "env_for_shift": np.array(optimizer.history_current_environment_for_shift),
        "env_for_species_radius": np.array(optimizer.history_current_environment_for_species_radius),
        # Novos históricos
        "total_particles": np.array(optimizer.history_total_particles),
        "total_valid_species_iter": np.array(optimizer.history_total_valid_species_iter),
        "active_species_iter": np.array(optimizer.history_active_species_iter),
        "fe_at_iteration_end": np.array(optimizer.history_fe_at_iteration_end)
    }
    return problem.CurrentError, offline_error_run, run_history