# gmpb_problem.py
import numpy as np
import math


class GMPBProblem:
    def __init__(self, PeakNumber, ChangeFrequency, Dimension, ShiftSeverity, EnvironmentNumber, MinCoordinate=-100,
                 MaxCoordinate=100):
        self.FE = 0
        self.PeakNumber = PeakNumber
        self.ChangeFrequency = ChangeFrequency
        self.Dimension = Dimension
        self.ShiftSeverity = ShiftSeverity
        self.EnvironmentNumber = EnvironmentNumber
        self.Environmentcounter = 0  # 0-indexed para Python
        self.RecentChange = False
        self.MaxEvals = self.ChangeFrequency * self.EnvironmentNumber

        self.MinCoordinate = MinCoordinate
        self.MaxCoordinate = MaxCoordinate
        self.MinHeight = 30.0
        self.MaxHeight = 70.0
        self.MinWidth = 1.0
        self.MaxWidth = 12.0
        self.MinAngle = -np.pi
        self.MaxAngle = np.pi
        self.MaxTau = 1.0
        self.MinTau = -1.0
        self.MaxEta = 20.0
        self.MinEta = -20.0

        self.HeightSeverity = 7.0
        self.WidthSeverity = 1.0
        self.AngleSeverity = np.pi / 9.0
        self.TauSeverity = 0.2
        self.EtaSeverity = 2.0
        # self.EllipticalPeaks = True # Não usado diretamente no fitness do ASPSO_GMPB, mas é um param do GMPB original

        self.OptimumValue = np.full(self.EnvironmentNumber, np.nan)
        self.OptimumID = np.full(self.EnvironmentNumber, np.nan, dtype=int)
        self.PeaksHeight = np.full((self.EnvironmentNumber, self.PeakNumber), np.nan)
        self.PeaksPosition = np.full((self.EnvironmentNumber, self.PeakNumber, self.Dimension), np.nan)
        self.PeaksWidth = np.full((self.EnvironmentNumber, self.PeakNumber, self.Dimension), np.nan)
        self.PeaksAngle = np.full((self.EnvironmentNumber, self.PeakNumber), np.nan)
        self.tau = np.full((self.EnvironmentNumber, self.PeakNumber), np.nan)
        self.eta = np.full((self.EnvironmentNumber, self.PeakNumber, 4), np.nan)

        self.InitialRotationMatrix = np.zeros((self.PeakNumber, self.Dimension, self.Dimension))
        # No MATLAB, RotationMatrix é um cell array. Em Python, uma lista de arrays 3D (um por ambiente)
        # Cada array 3D interno tem (PeakNumber, Dimension, Dimension)
        self.RotationMatrix = [np.zeros((self.PeakNumber, self.Dimension, self.Dimension)) for _ in
                               range(self.EnvironmentNumber)]

        self.CurrentError = np.full(self.MaxEvals, np.nan)

        self._initialize_first_environment()
        self._generate_subsequent_environments()

        self.Environmentcounter = 0  # Reset para o início da simulação

    def _rotation_sub_matrix(self, angle, dim, axis_i, axis_j):
        mat = np.eye(dim)
        # Convenção do MATLAB: M(ii,jj) = sin(teta); M(jj,ii) = -sin(teta);
        mat[axis_i, axis_i] = np.cos(angle)
        mat[axis_j, axis_j] = np.cos(angle)
        mat[axis_i, axis_j] = np.sin(angle)
        mat[axis_j, axis_i] = -np.sin(angle)
        return mat

    def _generate_rotation_matrix_for_benchmark(self, angle, dim):  # Renomeado para clareza
        if dim == 1:
            return np.array([[1.0]])

        output_matrix = np.eye(dim)
        num_basic_rotations = dim * (dim - 1) // 2
        if num_basic_rotations == 0:
            return output_matrix

        basic_rotations = []
        idx = 0
        for i in range(dim):
            for j in range(i + 1, dim):
                basic_rotations.append(self._rotation_sub_matrix(angle, dim, i, j))
                idx += 1

        permuted_indices = np.random.permutation(num_basic_rotations)
        for i in range(num_basic_rotations):
            output_matrix = output_matrix @ basic_rotations[permuted_indices[i]]
        return output_matrix

    def _initialize_first_environment(self):
        env_idx = 0
        self.PeaksPosition[env_idx, :, :] = self.MinCoordinate + (
                    self.MaxCoordinate - self.MinCoordinate) * np.random.rand(self.PeakNumber, self.Dimension)
        self.PeaksHeight[env_idx, :] = self.MinHeight + (self.MaxHeight - self.MinHeight) * np.random.rand(
            self.PeakNumber)
        self.PeaksWidth[env_idx, :, :] = self.MinWidth + (self.MaxWidth - self.MinWidth) * np.random.rand(
            self.PeakNumber, self.Dimension)

        self.OptimumValue[env_idx] = np.max(self.PeaksHeight[env_idx, :])
        self.OptimumID[env_idx] = np.argmax(self.PeaksHeight[env_idx, :])

        self.PeaksAngle[env_idx, :] = self.MinAngle + (self.MaxAngle - self.MinAngle) * np.random.rand(self.PeakNumber)
        self.tau[env_idx, :] = self.MinTau + (self.MaxTau - self.MinTau) * np.random.rand(self.PeakNumber)
        self.eta[env_idx, :, :] = self.MinEta + (self.MaxEta - self.MinEta) * np.random.rand(self.PeakNumber, 4)

        for ii in range(self.PeakNumber):
            if self.Dimension > 1:
                q, _ = np.linalg.qr(np.random.rand(self.Dimension, self.Dimension))
                self.InitialRotationMatrix[ii, :, :] = q
                # RotationMatrix para o ambiente 0, pico ii
                self.RotationMatrix[env_idx][ii, :, :] = q @ self._generate_rotation_matrix_for_benchmark(
                    self.PeaksAngle[env_idx, ii], self.Dimension)
            else:
                self.InitialRotationMatrix[ii, :, :] = np.array([[1.0]])
                self.RotationMatrix[env_idx][ii, :, :] = np.array([[1.0]])

    def _apply_boundary_conditions(self, values, min_val, max_val):
        # Implementação simples de reflexão (pode precisar de ajuste fino para múltiplas reflexões)
        # O código MATLAB faz uma única reflexão.
        # valores > max_val são refletidos para 2*max_val - valores
        # valores < min_val são refletidos para 2*min_val - valores
        values_copy = np.copy(values)  # Evitar modificar o array original diretamente se não for a intenção

        # Reflexão para limite superior
        over_max = values_copy > max_val
        values_copy[over_max] = (2 * max_val) - values_copy[over_max]
        # Se ainda estiver fora (ex: refletiu para muito abaixo do min_val), clipar
        # values_copy[values_copy < min_val] = min_val # Opcional: clipar após reflexão

        # Reflexão para limite inferior
        under_min = values_copy < min_val
        values_copy[under_min] = (2 * min_val) - values_copy[under_min]
        # Se ainda estiver fora (ex: refletiu para muito acima do max_val), clipar
        # values_copy[values_copy > max_val] = max_val # Opcional: clipar após reflexão

        # O código MATLAB não parece ter um clipe secundário após a reflexão.
        # Para corresponder, apenas a reflexão é aplicada.
        # No entanto, para robustez, um clipe final pode ser desejável na prática.
        # Re-aplicando a lógica de reflexão para garantir que esteja dentro dos limites,
        # ou simplesmente clipando, pois múltiplas reflexões podem ser complexas.
        # Vamos manter a reflexão simples e um clipe final para garantir que esteja nos limites.

        # Após reflexão simples, uma segunda passagem para garantir que está dentro:
        over_max_again = values_copy > max_val
        values_copy[over_max_again] = (2 * max_val) - values_copy[over_max_again]  # Reflete novamente
        under_min_again = values_copy < min_val
        values_copy[under_min_again] = (2 * min_val) - values_copy[under_min_again]  # Reflete novamente

        # Clipe final para garantir que está dentro dos limites estritos
        values_copy = np.clip(values_copy, min_val, max_val)
        return values_copy

    def _generate_subsequent_environments(self):
        for ii in range(1, self.EnvironmentNumber):
            prev_env_idx = ii - 1
            curr_env_idx = ii

            shift_offset = np.random.randn(self.PeakNumber, self.Dimension)
            norm_factor = np.linalg.norm(shift_offset, axis=1, keepdims=True)
            norm_factor[norm_factor == 0] = 1e-9  # Evitar divisão por zero
            shift = (shift_offset / norm_factor) * self.ShiftSeverity

            # Aplicar mudanças e condições de contorno
            self.PeaksPosition[curr_env_idx, :, :] = self._apply_boundary_conditions(
                self.PeaksPosition[prev_env_idx, :, :] + shift, self.MinCoordinate, self.MaxCoordinate)

            self.PeaksWidth[curr_env_idx, :, :] = self._apply_boundary_conditions(
                self.PeaksWidth[prev_env_idx, :, :] + (
                            np.random.randn(self.PeakNumber, self.Dimension) * self.WidthSeverity),
                self.MinWidth, self.MaxWidth)

            self.PeaksHeight[curr_env_idx, :] = self._apply_boundary_conditions(
                self.PeaksHeight[prev_env_idx, :] + (self.HeightSeverity * np.random.randn(self.PeakNumber)),
                self.MinHeight, self.MaxHeight)

            self.OptimumValue[curr_env_idx] = np.max(self.PeaksHeight[curr_env_idx, :])
            self.OptimumID[curr_env_idx] = np.argmax(self.PeaksHeight[curr_env_idx, :])

            self.PeaksAngle[curr_env_idx, :] = self._apply_boundary_conditions(
                self.PeaksAngle[prev_env_idx, :] + (self.AngleSeverity * np.random.randn(self.PeakNumber)),
                self.MinAngle, self.MaxAngle)

            self.tau[curr_env_idx, :] = self._apply_boundary_conditions(
                self.tau[prev_env_idx, :] + (self.TauSeverity * np.random.randn(self.PeakNumber)),
                self.MinTau, self.MaxTau)

            self.eta[curr_env_idx, :, :] = self._apply_boundary_conditions(
                self.eta[prev_env_idx, :, :] + (np.random.randn(self.PeakNumber, 4) * self.EtaSeverity),
                self.MinEta, self.MaxEta)

            for jj in range(self.PeakNumber):
                if self.Dimension > 1:
                    self.RotationMatrix[curr_env_idx][jj, :, :] = self.InitialRotationMatrix[jj, :,
                                                                  :] @ self._generate_rotation_matrix_for_benchmark(
                        self.PeaksAngle[curr_env_idx, jj], self.Dimension)
                else:
                    self.RotationMatrix[curr_env_idx][jj, :, :] = np.array([[1.0]])

    def _transform(self, X_coord_row_vec, tau_val, eta_params_for_peak):
        Y = np.zeros_like(X_coord_row_vec)  # Assegura que Y tenha a mesma forma

        # Lógica de transformação do MATLAB (aplicada por elemento)
        for i in range(len(X_coord_row_vec)):
            x_val = X_coord_row_vec[i]
            if x_val > 0:
                log_x = np.log(x_val)
                Y[i] = np.exp(
                    log_x + tau_val * (np.sin(eta_params_for_peak[0] * log_x) + np.sin(eta_params_for_peak[1] * log_x)))
            elif x_val < 0:
                log_neg_x = np.log(-x_val)
                Y[i] = -np.exp(log_neg_x + tau_val * (
                            np.sin(eta_params_for_peak[2] * log_neg_x) + np.sin(eta_params_for_peak[3] * log_neg_x)))
            else:  # x_val == 0
                Y[i] = 0
        return Y

    def calculate_fitness(self, X_solutions_array_2d):
        # X_solutions_array_2d é esperado como (N_solutions, Dimension)
        if X_solutions_array_2d.ndim == 1:
            X_solutions_array_2d = X_solutions_array_2d.reshape(1, -1)

        SolutionNumber, dim = X_solutions_array_2d.shape

        results = np.full(SolutionNumber, np.nan)
        env_idx_current = self.Environmentcounter  # Ambiente atual para cálculo de fitness

        for jj in range(SolutionNumber):
            # Lógica de parada antecipada do MATLAB
            if self.FE >= self.MaxEvals:  # Não self.RecentChange aqui, pois o fitness é calculado mesmo se RecentChange for true
                # A otimização principal lidará com RecentChange
                return results  # Retorna o que foi calculado até agora

            x_sol_row_vec = X_solutions_array_2d[jj, :]

            f_peaks_for_solution_jj = np.full(self.PeakNumber, np.nan)

            for k in range(self.PeakNumber):
                diff_vec_row = x_sol_row_vec - self.PeaksPosition[env_idx_current, k, :]
                Rot_k_matrix = self.RotationMatrix[env_idx_current][k, :, :]  # (D, D)

                # Termo 'a': (x - P_k)' * R_k' -> diff_vec_row @ Rot_k_matrix.T (1xD)
                term_a_input = diff_vec_row @ Rot_k_matrix.T
                transformed_a = self._transform(term_a_input,
                                                self.tau[env_idx_current, k],
                                                self.eta[env_idx_current, k, :])  # (1xD)

                # Termo 'b': R_k * (x - P_k) -> Rot_k_matrix @ diff_vec_row.T (Dx1)
                term_b_input_col_vec = Rot_k_matrix @ diff_vec_row.reshape(-1, 1)  # (Dx1)
                transformed_b_col_vec = self._transform(term_b_input_col_vec.flatten(),  # _transform espera 1D row-like
                                                        self.tau[env_idx_current, k],
                                                        self.eta[env_idx_current, k, :]).reshape(-1, 1)  # (Dx1)

                Widths_k_sq_diag_matrix = np.diag(self.PeaksWidth[env_idx_current, k, :] ** 2)  # (DxD)

                # Formula: H_k - sqrt(transformed_a @ Widths_k_sq_diag_matrix @ transformed_b_col_vec)
                quadratic_term_val = transformed_a @ Widths_k_sq_diag_matrix @ transformed_b_col_vec

                sqrt_term = 0
                if quadratic_term_val >= 0:  # Evitar erro com sqrt de negativo
                    sqrt_term = np.sqrt(quadratic_term_val)
                # else: sqrt_term permanece 0, ou pode ser uma penalidade

                f_peaks_for_solution_jj[k] = self.PeaksHeight[env_idx_current, k] - sqrt_term

            results[jj] = np.max(f_peaks_for_solution_jj)

            # Atualizar FE e CurrentError
            self.FE += 1
            # FE é 1-indexado para lógica de erro e mudança, mas 0-indexado para array CurrentError
            current_eval_idx_for_array = self.FE - 1

            if current_eval_idx_for_array < self.MaxEvals:
                solution_error = self.OptimumValue[env_idx_current] - results[jj]
                if (self.FE % self.ChangeFrequency) != 1 and current_eval_idx_for_array > 0:
                    if self.CurrentError[current_eval_idx_for_array - 1] < solution_error:
                        self.CurrentError[current_eval_idx_for_array] = self.CurrentError[
                            current_eval_idx_for_array - 1]
                    else:
                        self.CurrentError[current_eval_idx_for_array] = solution_error
                else:
                    self.CurrentError[current_eval_idx_for_array] = solution_error

            # Verificar mudança de ambiente APÓS esta avaliação
            if (self.FE % self.ChangeFrequency) == 0 and self.FE < self.MaxEvals:
                self.Environmentcounter += 1
                self.RecentChange = True

        return results  # Retorna um array 1D de fitness para as N_solutions