# asPSO_particle.py
import numpy as np


class Particle:
    def __init__(self, dimension, min_coord, max_coord):
        self.dimension = dimension
        self.min_coord = min_coord
        self.max_coord = max_coord

        # Inicializa as propriedades da partícula
        # Corresponde a Optimizer.X = LB + (UB-LB).*rand(npop,dimension) em InitializingOptimizer_ASPSO_GMPB.m
        self.X = np.random.uniform(low=self.min_coord, high=self.max_coord, size=self.dimension)

        # Corresponde a Optimizer.PbestPosition = Optimizer.X em InitializingOptimizer_ASPSO_GMPB.m
        self.PbestPosition = np.copy(self.X)

        # Corresponde a Optimizer.Velocity = zeros(npop,dimension) em InitializingOptimizer_ASPSO_GMPB.m
        self.Velocity = np.zeros(self.dimension)

        # FitnessValue é o fitness atual da partícula
        # PbestFitness é o melhor fitness encontrado pela partícula até agora
        # Corresponde a Optimizer.FitnessValue e Optimizer.PbestFitness em InitializingOptimizer_ASPSO_GMPB.m
        self.FitnessValue = -np.inf
        self.PbestFitness = -np.inf

        # Flags e armazenamento para o algoritmo ASPSO
        self.Processed = False  # Usado na criação de espécies (CreatingSpecies.m)
        self.Shifts = None  # Usado para estimar a severidade da mudança (Reaction_ASPSO_GMPB.m)
        # No MATLAB, é inicializado como [], pode ser None ou uma lista vazia.
        self.Pbest_past_environment = None  # Armazena PbestPosition antes de uma mudança ambiental (Reaction_ASPSO_GMPB.m)

    def initialize_fitness(self, problem_instance):
        """
        Calcula o fitness inicial da partícula e define seu Pbest inicial.
        Baseado em InitializingOptimizer_ASPSO_GMPB.m:
        [Optimizer.FitnessValue,Problem] = fitness_ASPSO_GMPB(Optimizer.X,Problem);
        if Problem.RecentChange == 0
            Optimizer.PbestFitness = Optimizer.FitnessValue;
        else
            Optimizer.FitnessValue = -inf(npop,1);
            Optimizer.PbestFitness = Optimizer.FitnessValue;
        end
        """
        # problem_instance.calculate_fitness espera um array 2D de soluções
        # O resultado é um array, então pegamos o primeiro (e único) elemento
        fitness_values = problem_instance.calculate_fitness(self.X.reshape(1, -1))
        self.FitnessValue = fitness_values[0] if fitness_values is not None and fitness_values.size > 0 else -np.inf

        # A lógica do MATLAB para Problem.RecentChange == 1 ao inicializar PbestFitness
        # (-inf) parece ser para um reset geral da população.
        # Para uma partícula recém-criada (seja no início ou durante a execução),
        # seu Pbest inicial é sua posição e fitness atuais.
        # A reavaliação e reset de Pbest após uma mudança ambiental é tratada
        # na função de reação do otimizador principal.
        if not problem_instance.RecentChange:  # Condição original do MATLAB
            self.PbestFitness = self.FitnessValue
            self.PbestPosition = np.copy(self.X)
        else:
            # Se RecentChange é true, o MATLAB define FitnessValue e PbestFitness como -inf.
            # Isso sugere que a partícula é "inválida" até ser reavaliada na nova função de reação.
            # No entanto, initialize_fitness já calculou um FitnessValue no novo ambiente.
            # Para consistência com a ideia de que uma nova partícula tem seu Pbest como estado atual:
            self.PbestFitness = self.FitnessValue
            self.PbestPosition = np.copy(self.X)
            # Uma alternativa mais próxima ao MATLAB seria:
            # self.FitnessValue = -np.inf # Sobrescreve o fitness calculado
            # self.PbestFitness = -np.inf
            # Mas isso parece contraintuitivo se o fitness já foi calculado no novo ambiente.
            # A função de reação no otimizador principal tipicamente lida com a reavaliação de toda a população
            # e o reset de Pbest após uma mudança.

    def update_pbest(self):
        """
        Atualiza a melhor posição pessoal (Pbest) da partícula se o fitness atual for melhor.
        Corresponde a:
        if Optimizer.Particle(Species(ii).member(jj)).FitnessValue > Optimizer.Particle(Species(ii).member(jj)).PbestFitness
            Optimizer.Particle(Species(ii).member(jj)).PbestFitness = Optimizer.Particle(Species(ii).member(jj)).FitnessValue;
            Optimizer.Particle(Species(ii).member(jj)).PbestPosition = Optimizer.Particle(Species(ii).member(jj)).X;
        end
        (de Optimization_ASPSO_GMPB.m)
        """
        if self.FitnessValue > self.PbestFitness:
            self.PbestFitness = self.FitnessValue
            self.PbestPosition = np.copy(self.X)

    def check_bounds(self):
        """
        Aplica restrições de contorno à posição da partícula e zera a velocidade
        para dimensões que saíram dos limites.
        Corresponde a:
        tmp1 = Optimizer.Particle(Species(ii).member(jj)).X < Optimizer.MinCoordinate;
        Optimizer.Particle(Species(ii).member(jj)).X(tmp1) = Optimizer.MinCoordinate;
        Optimizer.Particle(Species(ii).member(jj)).Velocity(tmp1) = 0;
        (de Optimization_ASPSO_GMPB.m)
        """
        # Limite inferior
        mask_low = self.X < self.min_coord
        self.X[mask_low] = self.min_coord
        self.Velocity[mask_low] = 0.0

        # Limite superior
        mask_high = self.X > self.max_coord
        self.X[mask_high] = self.max_coord
        self.Velocity[mask_high] = 0.0


# Exemplo de como você poderia testar esta classe (coloque em um bloco if __name__ == "__main__" ou em um script de teste separado):
if __name__ == '__main__':
    # Você precisaria de uma instância de GMPBProblem para testar initialize_fitness
    # Supondo que gmpb_problem.py existe e pode ser importado
    from gmpb_problem import GMPBProblem

    print("Testando a classe Particle...")

    # Parâmetros de exemplo para o problema
    params = {'PeakNumber': 5, 'ChangeFrequency': 100, 'Dimension': 2, 'ShiftSeverity': 1, 'EnvironmentNumber': 3}
    problem = GMPBProblem(**params)

    # Criar uma partícula
    particle_dim = params['Dimension']
    min_c = problem.MinCoordinate
    max_c = problem.MaxCoordinate

    p1 = Particle(dimension=particle_dim, min_coord=min_c, max_coord=max_c)
    print(f"Posição Inicial P1: {p1.X}")
    print(f"Velocidade Inicial P1: {p1.Velocity}")

    # Inicializar fitness da partícula
    p1.initialize_fitness(problem)  # problem.FE será incrementado aqui
    print(f"Fitness Inicial P1: {p1.FitnessValue}")  # Linha corrigida
    print(f"Pbest Fitness Inicial P1: {p1.PbestFitness}")
    print(f"Pbest Posição Inicial P1: {p1.PbestPosition}")

    # Simular uma melhoria no fitness
    # (Em um cenário real, X mudaria e seria reavaliado)
    p1.FitnessValue += 10
    p1.update_pbest()
    print(f"Novo Pbest Fitness P1 após melhoria simulada: {p1.PbestFitness}")

    # Testar limites
    p1.X = np.array([problem.MinCoordinate - 10, problem.MaxCoordinate + 10])
    p1.Velocity = np.array([1.0, 1.0])  # Velocidade antes de sair dos limites
    print(f"Posição P1 antes de check_bounds: {p1.X}")
    print(f"Velocidade P1 antes de check_bounds: {p1.Velocity}")
    p1.check_bounds()
    print(f"Posição P1 após check_bounds: {p1.X}")
    print(f"Velocidade P1 após check_bounds: {p1.Velocity}")  # Deve ser [0,0]

    print("\nTeste da partícula concluído.")