# asPSO_optimizer.py
import numpy as np
from scipy.spatial.distance import cdist
from asPSO_particle import Particle  # Mantém como estava
import math
from collections import namedtuple


class Species:
    def __init__(self, seed_index, member_indices, distance, active=True, removed=False):
        self.seed_index = seed_index
        self.member_indices = member_indices
        self.distance = distance
        self.active = active
        self.removed = removed


class ASPSOOptimizer:
    def __init__(self, problem_dimension, min_coord, max_coord, peak_number_initial,
                 swarm_member_size=5, initial_population_size=50, newly_added_population_size=5,
                 pso_inertia_weight=0.729843788, pso_c1=2.05, pso_c2=2.05,
                 n_max_species=30,
                 rho_deactivation=0.7, mu_deactivation=0.2, gamma_deactivation=0.1):

        # ... (inicialização dos parâmetros existentes permanece a mesma) ...
        self.dimension = problem_dimension
        self.min_coord = min_coord
        self.max_coord = max_coord
        self.swarm_member_size = swarm_member_size
        self.initial_population_size = initial_population_size
        self.newly_added_population_size = newly_added_population_size
        self.inertia_weight = pso_inertia_weight
        self.c1 = pso_c1
        self.c2 = pso_c2
        self.Nmax = n_max_species
        self.current_shift_severity = 1.0
        self.teta_tracker_threshold = self.current_shift_severity
        self.rho = rho_deactivation
        self.mu = mu_deactivation
        self.gamma = gamma_deactivation
        self.beta_deactivation = 1.0
        self.max_deactivation_radius = self.rho * self.current_shift_severity
        self.min_deactivation_radius = self.mu * np.sqrt(self.dimension) if self.dimension > 0 else 0
        self.current_deactivation_radius = self.max_deactivation_radius

        if peak_number_initial > 0 and self.dimension > 0:
            denominator = peak_number_initial ** (1.0 / self.dimension) if peak_number_initial > 0 else 1.0
            if denominator == 0: denominator = 1.0
            d_boa_initial = (self.max_coord - self.min_coord) / denominator
        else:
            d_boa_initial = (self.max_coord - self.min_coord) / 2.0
        self.exclusion_limit = 0.5 * d_boa_initial
        self.generate_radius = 0.3 * d_boa_initial
        self._last_d_boa = d_boa_initial
        self.particles = []
        self.species_list = []
        self.tracker_species_indices = []  # Mantido para lógica interna, mas não plotado diretamente
        self.num_trackers_previous_iteration = 0

        # --- LISTAS DE HISTÓRICO ATUALIZADAS/NOVAS ---
        self.history_num_species_after_creation = []
        self.history_num_valid_species_before_pso = []
        self.history_current_deactivation_radius = []
        self.history_estimated_shift_severity = []
        self.history_current_environment_for_shift = []
        self.history_current_environment_for_species_radius = []

        # Novas para os gráficos solicitados:
        self.history_total_particles = []
        self.history_total_valid_species_iter = []  # Total de espécies válidas (não removidas por exclusão)
        self.history_active_species_iter = []  # Total de espécies ativas (e não removidas)
        self.history_fe_at_iteration_end = []  # FEs no final de cada optimize_step

    def initialize_population(self, problem_instance):
        # ... (código existente) ...
        self.particles = []
        for _ in range(self.initial_population_size):
            p = Particle(self.dimension, self.min_coord, self.max_coord)
            p.initialize_fitness(problem_instance)
            self.particles.append(p)

    def _create_species(self):
        # ... (código existente) ...
        if not self.particles:
            self.species_list = []
            return

        num_particles = len(self.particles)
        for p_idx in range(num_particles):
            self.particles[p_idx].Processed = False

        sorted_particle_indices = sorted(range(num_particles),
                                         key=lambda i: self.particles[i].PbestFitness,
                                         reverse=True)
        new_species_list_temp = []
        # Otimização: Criar array NumPy de posições uma vez
        if num_particles > 0:
            all_pbest_positions_np = np.array([self.particles[i].PbestPosition for i in range(num_particles)])
        else:  # Caso self.particles esteja vazio, mas _create_species foi chamado (improvável aqui)
            all_pbest_positions_np = np.empty((0, self.dimension))

        for seed_candidate_original_idx in sorted_particle_indices:
            if not self.particles[seed_candidate_original_idx].Processed:
                current_seed_idx = seed_candidate_original_idx
                current_species_members_indices = [current_seed_idx]
                self.particles[current_seed_idx].Processed = True
                species_max_distance = 0.0

                if self.swarm_member_size > 1:
                    unprocessed_original_indices = [i for i in range(num_particles) if not self.particles[i].Processed]
                    if unprocessed_original_indices:
                        seed_pos_2d = self.particles[current_seed_idx].PbestPosition.reshape(1, -1)

                        # Filtrar all_pbest_positions_np para incluir apenas não processados
                        unprocessed_positions_np = all_pbest_positions_np[unprocessed_original_indices, :]

                        if unprocessed_positions_np.shape[0] > 0:  # Certificar que há posições não processadas
                            dists_to_seed = cdist(seed_pos_2d, unprocessed_positions_np).flatten()
                            sorted_local_indices_by_dist = np.argsort(dists_to_seed)
                            num_members_to_add = min(self.swarm_member_size - 1, len(unprocessed_original_indices))
                            current_max_dist_in_species = 0.0
                            for i in range(num_members_to_add):
                                local_idx = sorted_local_indices_by_dist[i]
                                original_member_idx_to_add = unprocessed_original_indices[local_idx]
                                current_species_members_indices.append(original_member_idx_to_add)
                                self.particles[original_member_idx_to_add].Processed = True
                                if dists_to_seed[local_idx] > current_max_dist_in_species:
                                    current_max_dist_in_species = dists_to_seed[local_idx]
                            species_max_distance = current_max_dist_in_species
                new_species_list_temp.append(Species(seed_index=current_seed_idx,
                                                     member_indices=current_species_members_indices,
                                                     distance=species_max_distance))
        self.species_list = new_species_list_temp
        self.history_num_species_after_creation.append(len(self.species_list))

    def _update_dynamic_radii(self):
        # ... (código existente) ...
        num_effective_species = len(self.species_list)
        if num_effective_species == 0:
            d_boa = self._last_d_boa
        else:
            denominator = num_effective_species ** (1.0 / self.dimension) if self.dimension > 0 else 1.0
            if denominator == 0: denominator = 1e-9
            d_boa = (self.max_coord - self.min_coord) / denominator
            self._last_d_boa = d_boa
        self.exclusion_limit = 0.5 * d_boa
        self.generate_radius = 0.3 * d_boa

    def optimize_step(self, problem_instance):
        # ... (início do optimize_step como antes) ...
        if not self.particles:
            if self.initial_population_size > 0:
                # print("População vazia detectada em optimize_step. Tentando repopular.") # Comentado para menos verbosidade
                self.initialize_population(problem_instance)
                if not self.particles:
                    # print("Falha ao repopular. Encerrando optimize_step.") # Comentado
                    return
            else:
                return

        self._create_species()
        self._update_dynamic_radii()

        # Coleta de dados para histórico ANTES da lógica principal da iteração, se necessário,
        # ou no final para refletir o estado da iteração.
        # history_num_species_after_creation já está em _create_species
        self.history_current_deactivation_radius.append(self.current_deactivation_radius)
        self.history_current_environment_for_species_radius.append(problem_instance.Environmentcounter)

        self.num_trackers_previous_iteration = len(
            self.tracker_species_indices)  # self.tracker_species_indices será recalculado
        self.tracker_species_indices = []

        best_tracker_species_obj_in_list = None
        best_tracker_fitness = -np.inf

        if self.species_list:
            for i, sp_obj in enumerate(self.species_list):
                if sp_obj.distance < self.teta_tracker_threshold:
                    self.tracker_species_indices.append(i)
                    seed_particle_global_idx = sp_obj.seed_index
                    current_seed_fitness = self.particles[seed_particle_global_idx].PbestFitness
                    if current_seed_fitness > best_tracker_fitness:
                        best_tracker_fitness = current_seed_fitness
                        best_tracker_species_obj_in_list = sp_obj

        particles_to_remove_global_indices = set()

        for i in range(len(self.species_list)):
            sp_i = self.species_list[i]
            if sp_i.removed: continue
            for j in range(i + 1, len(self.species_list)):
                sp_j = self.species_list[j]
                if sp_j.removed: continue
                seed_i_pos = self.particles[sp_i.seed_index].PbestPosition
                seed_j_pos = self.particles[sp_j.seed_index].PbestPosition
                dist_seeds = np.linalg.norm(seed_i_pos - seed_j_pos)
                if dist_seeds < self.exclusion_limit:
                    fitness_i_seed = self.particles[sp_i.seed_index].PbestFitness
                    fitness_j_seed = self.particles[sp_j.seed_index].PbestFitness
                    if fitness_i_seed < fitness_j_seed:
                        sp_i.removed = True
                        for member_idx in sp_i.member_indices:
                            particles_to_remove_global_indices.add(member_idx)
                    else:
                        sp_j.removed = True
                        for member_idx in sp_j.member_indices:
                            particles_to_remove_global_indices.add(member_idx)

        current_valid_tracker_species_objs = []
        new_best_tracker_species_obj_in_list = None  # Renomeado para clareza
        new_best_tracker_fitness = -np.inf
        for sp_obj in self.species_list:
            if not sp_obj.removed and sp_obj.distance < self.teta_tracker_threshold:
                current_valid_tracker_species_objs.append(sp_obj)
                seed_fitness = self.particles[sp_obj.seed_index].PbestFitness
                if seed_fitness > new_best_tracker_fitness:
                    new_best_tracker_fitness = seed_fitness
                    new_best_tracker_species_obj_in_list = sp_obj  # Agora é o objeto Species
        num_current_valid_trackers = len(current_valid_tracker_species_objs)

        if self.num_trackers_previous_iteration < num_current_valid_trackers:
            self.current_deactivation_radius = self.max_deactivation_radius
            self.beta_deactivation = 1.0

        all_valid_trackers_within_radius = True
        if num_current_valid_trackers > 0:
            for sp_tracker_obj in current_valid_tracker_species_objs:
                if sp_tracker_obj.distance > self.current_deactivation_radius:
                    all_valid_trackers_within_radius = False
                    sp_tracker_obj.active = True
                else:
                    if sp_tracker_obj != new_best_tracker_species_obj_in_list:  # Comparar objetos
                        sp_tracker_obj.active = False
                    else:
                        sp_tracker_obj.active = True
        else:
            all_valid_trackers_within_radius = False

        if all_valid_trackers_within_radius and num_current_valid_trackers > 0:
            if self.current_deactivation_radius > self.min_deactivation_radius:
                self.beta_deactivation *= self.gamma
                self.current_deactivation_radius = self.min_deactivation_radius + \
                                                   (
                                                               self.max_deactivation_radius - self.min_deactivation_radius) * self.beta_deactivation
                self.current_deactivation_radius = max(self.min_deactivation_radius, self.current_deactivation_radius)
                for sp_tracker_obj in current_valid_tracker_species_objs:
                    if sp_tracker_obj.distance > self.current_deactivation_radius:
                        sp_tracker_obj.active = True
                    elif sp_tracker_obj != new_best_tracker_species_obj_in_list:
                        sp_tracker_obj.active = False
                    if sp_tracker_obj == new_best_tracker_species_obj_in_list:
                        sp_tracker_obj.active = True

        for sp_obj in self.species_list:
            if not sp_obj.removed and sp_obj not in current_valid_tracker_species_objs:
                sp_obj.active = True

        num_valid_species_before_pso_val = sum(1 for sp in self.species_list if not sp.removed)
        self.history_num_valid_species_before_pso.append(num_valid_species_before_pso_val)

        all_valid_species_converged = True
        num_valid_species = 0
        for sp_obj in self.species_list:
            if not sp_obj.removed:
                num_valid_species += 1
                if sp_obj.distance > self.generate_radius:
                    all_valid_species_converged = False
                    break
        if num_valid_species == 0:
            all_valid_species_converged = False  # Ou True se quisermos adicionar partículas a uma população vazia

        if num_valid_species >= self.Nmax and all_valid_species_converged:
            all_valid_species_converged = False
            worst_swarm_fitness = np.inf
            worst_swarm_species_obj_to_reinit = None
            for sp_obj in self.species_list:
                if not sp_obj.removed:
                    seed_fitness = self.particles[sp_obj.seed_index].PbestFitness
                    if seed_fitness < worst_swarm_fitness:
                        worst_swarm_fitness = seed_fitness
                        worst_swarm_species_obj_to_reinit = sp_obj
            if worst_swarm_species_obj_to_reinit is not None:
                for member_particle_global_idx in worst_swarm_species_obj_to_reinit.member_indices:
                    new_p = Particle(self.dimension, self.min_coord, self.max_coord)
                    new_p.initialize_fitness(problem_instance)
                    self.particles[member_particle_global_idx] = new_p
                    if problem_instance.RecentChange: return
                worst_swarm_species_obj_to_reinit.active = True
                worst_swarm_species_obj_to_reinit.distance = np.inf

        for sp_obj in self.species_list:
            if sp_obj.active and not sp_obj.removed:
                seed_pbest_pos = self.particles[sp_obj.seed_index].PbestPosition
                for member_particle_global_idx in sp_obj.member_indices:
                    p = self.particles[member_particle_global_idx]
                    r1 = np.random.rand(self.dimension)
                    r2 = np.random.rand(self.dimension)
                    cognitive_comp = self.c1 * r1 * (p.PbestPosition - p.X)
                    social_comp = self.c2 * r2 * (seed_pbest_pos - p.X)
                    p.Velocity = self.inertia_weight * (p.Velocity + cognitive_comp + social_comp)
                    p.X += p.Velocity
                    p.check_bounds()
                    fitness_values_arr = problem_instance.calculate_fitness(p.X.reshape(1, -1))
                    p.FitnessValue = fitness_values_arr[
                        0] if fitness_values_arr is not None and fitness_values_arr.size > 0 else -np.inf
                    if problem_instance.RecentChange: return
                    p.update_pbest()

        if particles_to_remove_global_indices:
            sorted_indices_to_del = sorted(list(particles_to_remove_global_indices), reverse=True)
            temp_particles = [p for i, p in enumerate(self.particles) if i not in particles_to_remove_global_indices]
            self.particles = temp_particles  # Atualiza a lista de partículas

            self._create_species()  # Recria espécies com a população atualizada
            self._update_dynamic_radii()

        current_num_valid_species = sum(
            1 for sp in self.species_list if not sp.removed)  # Recalcula com a lista atual de espécies
        current_all_valid_species_converged = True
        if current_num_valid_species == 0:
            current_all_valid_species_converged = True  # Para permitir adição se Nmax não atingido
        else:
            for sp_obj in self.species_list:
                if not sp_obj.removed:  # Só considera espécies válidas
                    if sp_obj.distance > self.generate_radius:
                        current_all_valid_species_converged = False
                        break

        if current_num_valid_species < self.Nmax and current_all_valid_species_converged:
            num_particles_to_add_now = 0
            max_total_particles = self.Nmax * self.swarm_member_size
            for _ in range(self.newly_added_population_size):
                if len(self.particles) < max_total_particles:
                    new_p = Particle(self.dimension, self.min_coord, self.max_coord)
                    new_p.initialize_fitness(problem_instance)
                    self.particles.append(new_p)
                    num_particles_to_add_now += 1
                    if problem_instance.RecentChange: return
                else:
                    break
            if num_particles_to_add_now > 0:
                self._create_species()
                self._update_dynamic_radii()

        # --- REGISTRAR HISTÓRICO NO FINAL DA ITERAÇÃO ---
        self.history_total_particles.append(len(self.particles))
        num_total_valid_species_final = sum(1 for sp in self.species_list if not sp.removed)
        num_active_valid_species_final = sum(1 for sp in self.species_list if sp.active and not sp.removed)
        self.history_total_valid_species_iter.append(num_total_valid_species_final)
        self.history_active_species_iter.append(num_active_valid_species_final)
        self.history_fe_at_iteration_end.append(problem_instance.FE)

    def reaction_to_change(self, problem_instance):
        # ... (início da reaction_to_change como antes) ...
        trackers_for_reaction = []
        if self.species_list:
            for sp_obj in self.species_list:
                if not sp_obj.removed and hasattr(sp_obj,
                                                  'distance') and sp_obj.distance < self.teta_tracker_threshold:  # Checa se sp_obj.distance existe
                    trackers_for_reaction.append(sp_obj)

        measured_shifts_values = []
        if trackers_for_reaction:
            for sp_tracker_obj in trackers_for_reaction:
                seed_particle_idx = sp_tracker_obj.seed_index
                if 0 <= seed_particle_idx < len(self.particles):  # Checagem de índice
                    seed_p = self.particles[seed_particle_idx]
                    if seed_p.Pbest_past_environment is not None and seed_p.PbestPosition is not None:
                        shift_val = np.linalg.norm(seed_p.Pbest_past_environment - seed_p.PbestPosition)
                        seed_p.Shifts = shift_val
                        measured_shifts_values.append(shift_val)
                    seed_p.Pbest_past_environment = None

        if measured_shifts_values:
            self.current_shift_severity = np.mean(measured_shifts_values)

        self.history_estimated_shift_severity.append(self.current_shift_severity)
        self.history_current_environment_for_shift.append(problem_instance.Environmentcounter)

        if trackers_for_reaction:
            for sp_tracker_obj in trackers_for_reaction:
                seed_idx = sp_tracker_obj.seed_index
                if not (0 <= seed_idx < len(self.particles)): continue  # Pula se índice inválido

                seed_p = self.particles[seed_idx]
                pbest_pos_of_seed_before_X_update = np.copy(seed_p.PbestPosition)
                for member_idx in sp_tracker_obj.member_indices:
                    if not (0 <= member_idx < len(self.particles)): continue  # Pula se índice inválido
                    p_member = self.particles[member_idx]
                    if member_idx == seed_idx:
                        p_member.X = np.copy(pbest_pos_of_seed_before_X_update)
                    else:
                        R_vec = np.random.randn(self.dimension)
                        norm_R = np.linalg.norm(R_vec)
                        if norm_R == 0: norm_R = 1e-9
                        shift_for_member_dispersion = (R_vec / norm_R) * self.current_shift_severity
                        p_member.X = pbest_pos_of_seed_before_X_update + shift_for_member_dispersion
                seed_p.Pbest_past_environment = pbest_pos_of_seed_before_X_update

        for p in self.particles:
            p.check_bounds()

        for p in self.particles:
            fitness_values_arr = problem_instance.calculate_fitness(p.X.reshape(1, -1))
            p.FitnessValue = fitness_values_arr[
                0] if fitness_values_arr is not None and fitness_values_arr.size > 0 else -np.inf
            p.PbestFitness = p.FitnessValue
            p.PbestPosition = np.copy(p.X)

        self.max_deactivation_radius = self.rho * self.current_shift_severity
        self.current_deactivation_radius = self.max_deactivation_radius
        self.teta_tracker_threshold = self.current_shift_severity
        self.beta_deactivation = 1.0
        if self.species_list:
            for sp_obj in self.species_list:
                sp_obj.active = True
                sp_obj.removed = False

        # --- REGISTRAR HISTÓRICO APÓS REAÇÃO (ESTADO FINAL DA POPULAÇÃO/ESPÉCIES PARA ESTA "ITERAÇÃO DE REAÇÃO") ---
        self.history_total_particles.append(len(self.particles))
        num_total_valid_species_final_reaction = sum(1 for sp in self.species_list if not sp.removed)
        num_active_valid_species_final_reaction = sum(
            1 for sp in self.species_list if sp.active and not sp.removed)  # Todas deveriam estar ativas
        self.history_total_valid_species_iter.append(num_total_valid_species_final_reaction)
        self.history_active_species_iter.append(num_active_valid_species_final_reaction)
        self.history_fe_at_iteration_end.append(problem_instance.FE)
        # O raio de deativação e o ambiente para ele já são registrados no início do optimize_step
        # A severidade da mudança estimada e o ambiente para ela já são registrados acima nesta função.